#include <iostream>             // cout, cerr
#include <cstdlib>              // EXIT_FAILURE
#include <GL/glew.h>            // GLEW library
#include <GLFW/glfw3.h>         // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <set>
#include "Cylinder.h"


//#define STB_IMAGE_IMPLEMENTATION
//#include "stb_image.h"     // Image loading functions


using namespace std;

//shader program Macro
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif



// using the unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Module 6 Milestone"; //window title


    const int WINDOW_WIDTH = 800; //window width
    const int WINDOW_HEIGHT = 600; // window height

    struct GLMesh { //stores the GL data to a given mesh

        GLuint vao; //handle for Vertex Array Object
        GLuint vao2;
        GLuint vbo; // handle for Vertex Buffer Object
        GLuint vbo2;
        GLuint nVertices; // number of indices in the mesh
        GLuint nIndices;

    };


    //window in GLFW
    GLFWwindow* gWindow = nullptr;

    //mesh data for triangle
    GLMesh gMesh;

    // Texture id
    GLuint gMyTexture;
    GLuint gMyTexture2;

    //shader program
    GLuint gMyShader;
    GLuint gMyShader2;
    GLuint gLight1;
    GLuint gLight2;



    //scaling factors
    GLuint gTextureId;
    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Cube and light color
    glm::vec3 gObjectColor(0.0f, 0.0f, 0.0f);
    glm::vec3 gLight1Color(1.0f, 1.0f, 1.0f);
    glm::vec3 gLight2Color(0.0f, 0.0f, 1.0f);

    // Light position and scale
    glm::vec3 gLight1Position(1.5f, 0.5f, 3.0f);
    glm::vec3 gLight1Scale(0.3f);

    // Light position and scale
    glm::vec3 gLight2Position(0.0f, 0.7f, 0.0f);
    glm::vec3 gLight2Scale(0.3f);

    //initial camera variables
    glm::vec3 gCamera = glm::vec3(0.0f, 0.0f, 3.0f);
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    glm::vec3 gCameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
    glm::vec3 gCameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
    glm::vec3 gCameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
    bool gFirstMouse = true;

    //setting timing variables
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    float cameraSpeed = 0.05f;

    // Light position and scale
    glm::vec3 gLight1Position(1.5f, 0.5f, 3.0f);
    glm::vec3 gLight1Scale(0.3f);

    // Light position and scale
    glm::vec3 gLight2Position(0.0f, 0.7f, 0.0f);
    glm::vec3 gLight2Scale(0.3f);

}

// Initializing the methods
bool UInitialize(int, char* [], GLFWwindow** window);
void UProcessInput(GLFWwindow* window);
void display(GLFWwindow* window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UMouseCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& myTexture);
void UDestroyTexture(GLuint myTexture);
void DrawCylinder(GLMesh& mesh);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& myShader);
void UDestroyShaderProgram(GLuint myShader);


// first light vertex Shader
const GLchar* light1VertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; //vertex data from the vertex attribure pointer0
layout(location = 1) in vec4 color; //color information from the vertex attribute pointer at 1

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader

//global variables for the matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); //converts vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); //gets pixel position in world space

    vertexNormal = mat3(transpose(inverse(model))) * normal; //get normal vectors in world space 
}
);

// second light fragment shader
const GLchar* light1FragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;

void main()
{
    //ambient lighting
    float ambientStrength = 1.0f; //setting ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; //generating ambient light color

    //diffuse lighting
    vec3 norm = normalize(vertexNormal); // Normalizing vectors to 1
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); //calculating distance between fragments on the pyramid and light surce
    float impact = max(dot(norm, lightDirection), 0.0);//calculating diffuse impact
    vec3 diffuse = impact * lightColor; //calculating diffuse light color

    //specular lighting
    float specularIntensity = 1.0f; // Setting specular strength
    float highlightSize = 16.0f; // setting specular highlight size variable 
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); //calculating the view directions
    vec3 reflectDir = reflect(-lightDirection, norm);//calculating reflection

    //calculating specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    //calculating phong vector
    vec3 phong = (ambient + diffuse + specular) * objectColor;

    fragmentColor = vec4(phong, 1.0f); //sedning results to GPU
}
);

//lamp 2 Vertex Shader
const GLchar* light2VertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; //vertex data from the vertex attribure pointer0
layout(location = 1) in vec4 color; //color information from the vertex attribute pointer at 1

out vec3 vertexNormal2; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos2; // For outgoing color / pixels to fragment shader

//global variables for the matrices
uniform mat4 model2;
uniform mat4 view2;
uniform mat4 projection2;

void main()
{
    gl_Position = projection2 * view2 * model2 * vec4(position, 1.0f); //converts vertices into clip coordinates

    vertexFragmentPos = vec3(model2 * vec4(position2, 1.0f)); //gets pixel position in world space

    vertexNormal2 = mat3(transpose(inverse(model2))) * normal; //get normal vectors in world space 
}
);


//lamp 2 fragment shader
const GLchar* light2FragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position

out vec4 fragmentColor2; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor2;
uniform vec3 lightColor2;
uniform vec3 lightPos2;
uniform vec3 viewPosition2;

void main()
{
    //ambient lighting
    float ambientStrength = 0.1f; //setting ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; //generating ambient light color

    //diffuse lighting
    vec3 norm2 = normalize(vertexNormal); // Normalizing vectors to 1
    vec3 lightDirection2 = normalize(lightPos - vertexFragmentPos); //calculating distance between fragments on the pyramid and light surce
    float impact2 = max(dot(norm2, lightDirection2), 0.0);//calculating diffuse impact
    vec3 diffuse2 = impact2 * lightColor2; //calculating diffuse light color

    //specular lighting
    float specularIntensity = 0.1f; // Setting specular strength
    float highlightSize = 16.0f; // setting specular highlight size variable 
    vec3 viewDir2 = normalize(viewPosition - vertexFragmentPos); //calculating the view directions
    vec3 reflectDir2 = reflect(-lightDirection, norm);//calculating reflection

    //calculating specular component
    float specularComponent2 = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular2 = specularIntensity * specularComponent * lightColor;

    //calculating phong vector
    vec3 phong2 = (ambient2 + diffuse2 + specular2) * objectColor;

    fragmentColor = vec4(phong, 1.0f); //sedning results to GPU
}
);


//vertex shader for cube
const GLchar* cubeVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; //vertex data from the vertex attribure pointer0
layout(location = 1) in vec4 color; //color information from the vertex attribute pointer at 1
layout(location = 2) in vec2 textureCoordinate;

out vec2 vertexTextureCoordinate;

out vec4 vertexColor;


//Tramnsform matrices global variables
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() { //every shader program needs a main function

    gl_Position = projection * view * model * vec4(position, 1.0f); // transforming vertices to clip coordinates 
    vertexColor = color; //referencing incoming color data
    vertexTextureCoordinate = textureCoordinate;

}
);

//Fragment shader for cube
const GLchar* cubeFragmentShaderSource = GLSL(440,
    in vec2 vertexTextureCoordinate; // takes the vertex texture coordinates as input

in vec4 vertexColor; //holds the color data from the vertex shader
out vec4 fragmentColor;//creates vector fragmentColor

//declaring uniformity
uniform sampler2D uTexture;
uniform vec2 uvScale;

void main() { //again a main funciton is needed

    fragmentColor = texture(uTexture, vertexTextureCoordinate * uvScale);

}

);


//Plane vertex shader
const GLchar* planeVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; //vertex data from the vertex attribure pointer0
layout(location = 1) in vec4 color; //color information from the vertex attribute pointer at 1
layout(location = 2) in vec2 textureCoordinate;

out vec2 vertexTextureCoordinate;

out vec4 vertexColor;


//Tramnsform matrices global variables
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() { //every shader program needs a main function

    gl_Position = projection * view * model * vec4(position, 1.0f); // transforming vertices to clip coordinates 
    vertexColor = color; //referencing incoming color data
    vertexTextureCoordinate = textureCoordinate;

}
);

//plane fragment shader 
const GLchar* planeFragmentShaderSource = GLSL(440,
    in vec2 vertexTextureCoordinate; // takes the vertex texture coordinates as input

in vec4 vertexColor; //holds the color data from the vertex shader
out vec4 fragmentColor;//creates vector fragmentColor

//declaring uniformity
uniform sampler2D uTexture;
uniform vec2 uvScale;

void main() { //again a main funciton is needed

    fragmentColor = texture(uTexture, vertexTextureCoordinate * uvScale);

}
);



//This function will reverese the Y-axis sinceit gets imported upside down
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1]; // creating a temporary variable
            image[index1] = image[index2];
            image[index2] = tmp; //setting the image index 2 to the temporary variable
            ++index1; // incrementing index
            ++index2;
        }
    }
}


// main function
int main(int argc, char* argv[])
{
    // main  window
    GLFWwindow* window = nullptr;

    if (!UInitialize(argc, argv, &window)) //initializing the window before the loop
        return EXIT_FAILURE;

    const char* texFilename = "../../Textures/chargingCubeTexture.png"; // opening the texture
    if (!UCreateTexture(texFilename, gMyTexture))
    {
        cout << "Failed to load the charging cube texture " << texFilename << endl; // if texture failed to load, this error message will print. 
        return EXIT_FAILURE;
    }

    const char* texFilename2 = "../../Textures/deskMat.png "; // opening the texture
    if (!UCreateTexture(texFilename2, gMyTexture2))
    {
        cout << "Failed to load the plane texture " << texFilename2 << endl; // if plane texture did not load then it will display this error message
        return EXIT_FAILURE;
    }

    //creates the mesh
    UCreateMesh(gMesh); //calls UCreateMesh to create a VBO 

    //creates shader program
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gMyShader))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(planeVertexShaderSource, planeFragmentShaderSource, gMyShader2))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(light1VertexShaderSource, light1FragmentShaderSource, gLight1))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(light2VertexShaderSource, light2FragmentShaderSource, gLight2))
        return EXIT_FAILURE;

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gMyShader);

    //set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gMyShader, "uTexture"), 0);

    // sets the window background to black
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glm::mat4 model;

    // render(game) loop
    while (!glfwWindowShouldClose(gWindow))
    {
        // input
        UProcessInput(gWindow);

        //calls the render funciton
        URender();

        glBindVertexArray(gMesh.vao); //calling the vaos in the render loop

        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)); //setting the model matrix for the first vao

        glDrawArrays(GL_TRIANGLES, 0, 6); // drawing ithe plane out

        glBindVertexArray(gMesh.vao2);

        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f)); //setting model matrix for second vao

        glDrawArrays(GL_TRIANGLES, 0, 12); //drawing the cube out

        void display(GLFWwindow * window); //calling the erspective and orthographic views

        glfwPollEvents();

    }

    glfwSetCursorPosCallback(window, UMouseCallback);


    //destroy mesh data
    UDestroyMesh(gMesh);


    // Releases the texture
    UDestroyTexture(gMyTexture);


    //destroy shader program

    UDestroyShaderProgram(gMyShader);
    UDestroyShaderProgram(gMyShader2);
    UDestroyShaderProgram(gLight1);
    UDestroyShaderProgram(gLight2);

    exit(EXIT_SUCCESS); // correctly ends program
}


// initializes  the GLFW, GLEW
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    //initialize methods used
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // Creates glfw window 
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        cout << "FAILED TO CREATE GLFW WINDOW!" << endl; // displays error message if window was not created
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);

    //Initializing GLEW
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << endl;
        return false;
    }

    // Displays OpenGL version we are using
    cout << "OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: keys are pressed/released
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) //if escape key is pressed. the program will exit
        glfwSetWindowShouldClose(window, true);

    float cameraOffset = cameraSpeed * gDeltaTime;

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)// if the W key is pressed, the camera will move forward
        gCameraPos += cameraOffset * gCameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)// if the S key is pressed, the camera will move backward
        gCameraPos -= cameraOffset * gCameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)// if the A key is pressed, the camera will move left
        gCameraPos -= glm::normalize(glm::cross(gCameraFront, gCameraUp)) * cameraOffset;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)// if the D key is pressed, the camera will move right
        gCameraPos += glm::normalize(glm::cross(gCameraFront, gCameraUp)) * cameraOffset;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)// if the Q key is pressed, the camera will move upward
        gCameraPos += cameraOffset * gCameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)// if the E key is pressed, the camera will move downward
        gCameraPos -= gCameraUp * cameraOffset;
};

void display(GLFWwindow* window) //create the different displays
{
    if (glfwGetKey(gWindow, GLFW_KEY_P) == GLFW_PRESS)//if p is pressed 
    {
        glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT); //update viewport function
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(60.0, WINDOW_WIDTH / WINDOW_HEIGHT, 1.0, 100.0); //create perspective view
        glMatrixMode(GL_MODELVIEW);
    }
    else //if not
    {
        glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT); // update viewport function
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-1.0, 1.0, -1.0, 1.0, 1.0, 100.0); //create orthographic view using glOrtho
        glMatrixMode(GL_MODELVIEW);
    }
}



// glfw: whenever the window size changed this executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);//using the glViewport function
}


void UMouseCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }
    float xoffset = xpos - gLastX; //setting the xoffset
    float yoffset = gLastY - ypos; //setting the yoffset

    gLastX = xpos; //setting mouse position
    gLastY = ypos;

    GLfloat sensitivity = 0.05f; //sensitivity settings for camera
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    //update the Yaw and Pitch variables 
    GLfloat yaw = -90.0f;
    GLfloat Pitch = 0.0f;

    yaw += xoffset;
    Pitch += yoffset;

    if (Pitch > 89.0f) { //if user goes over 89 degrees 

        Pitch = 89.0f; //it will remain at 89 degrees
    }
    if (Pitch < -89.0f) { //if user goes under 89 degrees

        Pitch = -89.0f; //the camera will remain at 89 degrees
    }

    // we also need to adjust the front camera 
    glm::vec3 frontCam;

    //updating camera vectors
    frontCam.x = cos(glm::radians(yaw)) * cos(glm::radians(Pitch)); //updating x-axis
    frontCam.y = sin(glm::radians(Pitch)); //updating y axis
    frontCam.z = sin(glm::radians(yaw) * cos(glm::radians(Pitch)));//updating z-axis
    gCameraFront = glm::normalize(frontCam); //updating the frontcamera
}


// this function is for the scroll wheel on the mouse
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset) {
    cameraSpeed += yoffset * 0.5f; //when scrolled, it will adjust the camera speed
}


// Functioned called to render a frame
void URender()
{
    //enables z-depth for 3D
    glEnable(GL_DEPTH_TEST);


    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);//clears the window
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // clears the buffer

    //scales the cube obect by 1
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    // rotates shape by 90 degrees in the x axis, rotates the object ot give it the laying down effect
    glm::mat4 rotation = glm::rotate(90.0f, glm::vec3(1.9f, 3.0f, 2.0f));
    // offsets the obeject to the left and up and backs camera up
    glm::mat4 translation = glm::translate(glm::vec3(-1.5f, 0.5f, -4.0f));
    // creates the model matrix
    glm::mat4 model = translation * rotation * scale;

    // moves the camera to the left (x-axis), up the y-axis and moves the camera back (z axis)
    glm::mat4 view = glm::translate(glm::vec3(-0.5f, 1.5f, -7.0f));

    // Creates a Field of view
    glm::mat4 projection = glm::perspective(45.0f, (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Sets the shader named myShader to be used
    glUseProgram(gMyShader);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gMyShader, "model");
    GLint viewLoc = glGetUniformLocation(gMyShader, "view");
    GLint projLoc = glGetUniformLocation(gMyShader, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    GLint UVScaleLoc = glGetUniformLocation(gMyShader, "uvScale"); //gets the uniform location of the shader
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));


    //references the uiniform matrx from the shaderprogram for the color of the cube, light color, light position, and camera psoiton
    GLint objectColorLoc = glGetUniformLocation(gMyShader, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gMyShader, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gMyShader, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gMyShader, "viewPosition");

    //passes color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLight1Color.r, gLight1Color.g, gLight1Color.b);
    glUniform3f(lightColorLoc, gLight2Color.r, gLight2Color.g, gLight2Color.b);
    glUniform3f(lightPositionLoc, gLight1Position.x, gLight1Position.y, gLight1Position.z);
    glUniform3f(lightPositionLoc, gLight2Position.x, gLight2Position.y, gLight2Position.z);



    //declare the use of the light 1 shader
    glUseProgram(gLight1);

    //transforms the cube visual for the first light source
    model = glm::translate(gLight1Position) * glm::scale(gLight1Scale);

    //reference matrix uniforms from the Lamp1 shader 
    modelLoc = glGetUniformLocation(gLight1, "model");
    viewLoc = glGetUniformLocation(gLight1, "view");
    projLoc = glGetUniformLocation(gLight1, "projection");

    //pass matrix data to the Lamp1 Shader matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gMesh.nIndices);


    //declare the use of the light 2 shader
    glUseProgram(gLight2);

    //transforms the cube visual for the second light source
    model = glm::translate(gLight2Position) * glm::scale(gLight2Scale);

    //reference matrix uniforms from the Lamp1 shader 
    modelLoc = glGetUniformLocation(gLight2, "model");
    viewLoc = glGetUniformLocation(gLight2, "view");
    projLoc = glGetUniformLocation(gLight2, "projection");

    //pass matrix data to the Lamp1 Shader matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawArrays(GL_TRIANGLES, 0, gMesh.nIndices);


    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    glDrawArrays(GL_TRIANGLES, 100, gMesh.nVertices); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer each frame.
}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    // Vertex data
    GLfloat verts[] = {
        //vertex coordinates        Color Data(RGBA)        Texture                        
        -5.0f, 0.0f, -5.0f,     0.0f, 0.0f, 0.0f, 1.0f,     0.1f, 0.5f, //plane under charger cube
        5.0f, 0.0f, -5.0f,      0.0f, 0.0f, 0.0f, 1.0f,     0.0f, 0.3f,
        5.0f, 0.0f, 5.0f,       0.0f, 0.0f, 0.0f, 1.0f,     0.6f, 0.7f,
        5.0f, 0.0f, 5.0f,       0.0f, 0.0f, 0.0f, 1.0f,     0.4f, 0.8f,
        -5.0f, 0.0f, 5.0f,      0.0f, 0.0f, 0.0f, 1.0f,     0.7f, 0.9f,
        -5.0f, 0.0f, 5.0f,      0.0f, 0.0f, 0.0f, 1.0f,     0.2f, 0.4f,


        // Vertex Positions    // Colors (r,g,b,a)                                   Normalizing
        -0.5f, -0.5f, -0.5f,    1.0f, 0.0f, 0.0f, 1.0f,      0.1f, 0.75f,         0.0f,  0.0f, -1.0f, // back left side of cube 
        0.5f, -0.5f, -0.5f,     1.0f, 0.0f, 0.0f, 1.0f,      0.0f, 0.0f,          0.0f,  0.0f, -1.0f,
        0.5f, 0.5f, -0.5f,      1.0f, 0.0f, 0.0f, 1.0f,      0.4f, 0.3f,          0.0f,  0.0f, -1.0f,
        0.5f, 0.5f, -0.5f,      1.0f, 0.0f, 0.0f, 1.0f,      0.0f, 0.5f,          0.0f,  0.0f, -1.0f,
        -0.5f, 0.5f, -0.5f,     1.0f, 0.0f, 0.0f, 1.0f,      0.2f, 0.1f,          0.0f,  0.0f, -1.0f,
        -0.5f, -0.5f, -0.5f,    1.0f, 0.0f, 0.0f, 1.0f,     0.3f, 0.8f,           0.0f,  0.0f, -1.0f,

        -0.5f, -0.5f, 0.5f,     1.0f, 1.0f, 1.0f, 1.0f,      0.4f, 0.3f,          0.0f,  0.0f, 1.0f,// right side of charging cube
        0.5f, -0.5f, 0.5f,      1.0f, 1.0f, 1.0f, 1.0f,      0.5f, 0.5f,            0.0f,  0.0f, 1.0f,
        0.5f, 0.5f, 0.5f,       1.0f, 1.0f, 1.0f, 1.0f,     0.2f, 0.6f,             0.0f,  0.0f, 1.0f,
        0.5f, 0.5f, 0.5f,       1.0f, 1.0f, 1.0f, 1.0f,     0.5f, 0.5f,             0.0f,  0.0f, 1.0f,
        -0.5f, 0.5f, 0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     0.6f, 0.4f,             0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, 0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     0.0f, 0.0f,             0.0f,  0.0f, 1.0f,

        -0.5f, 0.5f, 0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     0.0f, 0.0f,             -1.0f,  0.0f, 0.0f,// left side of charging cube
        -0.5f, 0.5f, -0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     0.1f, 0.4f,             -1.0f,  0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,    1.0f, 1.0f, 1.0f, 1.0f,     0.2f, 0.1f,             -1.0f,  0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,    1.0f, 1.0f, 1.0f, 1.0f,     0.5f, 0.5f,             -1.0f,  0.0f, 0.0f,
        -0.5f, -0.5f, 0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     0.3f, 0.6f,             -1.0f,  0.0f, 0.0f,
        -0.5f, 0.5f, 0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     0.2f, 0.8f,             -1.0f,  0.0f, 0.0f,

        0.5f, 0.5f, 0.5f,       1.0f, 1.0f, 1.0f, 1.0f,     0.5f, 0.4f,             1.0f,  0.0f, 0.0f,//back right of charging cube
        0.5f, 0.5f, -0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     0.6f, 0.7f,             1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     1.0f, 0.3f,             1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     0.5f, 0.5f,             1.0f,  0.0f, 0.0f,
        0.5f, -0.5f, 0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     0.1f, 0.3f,             1.0f,  0.0f, 0.0f,
        0.5f, 0.5f, 0.5f,       1.0f, 1.0f, 1.0f, 1.0f,     0.2f, 0.3f,             1.0f,  0.0f, 0.0f,

        -0.5f, -0.5f, -0.5f,    1.0f, 1.0f, 1.0f, 1.0f,     0.0f, 0.5f,            0.0f,  -1.0f, 0.0f,//bottom side of charing cube
        0.5f, -0.5f, -0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     1.0f, 1.0f,             0.0f,  -1.0f, 0.0f,
        0.5f, -0.5f, 0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     1.0f, 1.0f,             0.0f,  -1.0f, 0.0f,
        0.5f, -0.5f, 0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     1.0f, 1.0f,             0.0f,  -1.0f, 0.0f,
        -0.5f, -0.5f, 0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     1.0f, 1.0f,             0.0f,  -1.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,    1.0f, 1.0f, 1.0f, 1.0f,     1.0f, 1.0f,             0.0f,  -1.0f, 0.0f,

        -0.5f, 0.5f, -0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     0.0f, 0.0f,            0.0f,  1.0f, 0.0f,//Top of charging cube
        0.5f, 0.5f, -0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     0.0f, 0.6f,             0.0f,  1.0f, 0.0f,
        0.5f, 0.5f, 0.5f,       1.0f, 1.0f, 1.0f, 1.0f,     0.1f, 0.2f,             0.0f,  1.0f, 0.0f,
        0.5f, 0.5f, 0.5f,       1.0f, 1.0f, 1.0f, 1.0f,     0.3f, 0.2f,             0.0f,  1.0f, 0.0f,
        -0.5f, 0.5f, 0.5f,      1.0f, 1.0f, 1.0f, 1.0f,     0.9f, 0.2f,             0.0f,  1.0f, 0.0f,
        -0.5f, 0.5f, -0.5f,     1.0f, 1.0f, 1.0f, 1.0f,     0.8f, 0.1f,             0.0f,  1.0f, 0.0f,

    
    
    };

    

    // Data for the indices
    GLushort indices[] = { 0, 1, 3,  // Triangle 1
                           1, 2, 3   // Triangle 2
    };


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;
    const GLuint floatsPerNorm = 3;

    unsigned int VBO, VAO;
    unsigned int VBO2, VAO2;



    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerColor + floatsPerUV + floatsPerNorm));

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO); //binding the first VAO
    glBindBuffer(GL_ARRAY_BUFFER, VBO); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);



    // Strides between vertex coordinates accounting for the texture coordiates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV + floatsPerColor + floatsPerNorm);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glGenVertexArrays(1, &VAO2); //activating the second VAO
    glGenBuffers(1, &VBO2);
    glBindVertexArray(VAO2);
    glBindBuffer(GL_ARRAY_BUFFER, VBO2);
    glGenVertexArrays(1, &mesh.vao); // We can also generate multiple VAOs or buffers at the same time.
    glBindVertexArray(mesh.vao);

    // Create VBO.
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU


    // Create Vertex Attribute Pointers.
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);
}

void Cylinder(float baseRadius, float topRadius, float height, int sectors,
    int stacks, bool smooth, int up) {
    : interleavedStride(32)

    set(baseRadius, topRadius, height, sectors, stacks, smooth, up);
}

void DrawCylinder(GLMesh& mesh)
{
    GLfloat degrees = 88;
    double radius = 2;
    double height = 1;
    double resolution = 0.1;
    drawCylinder(4, -4, radius, height, 255, 255, 0, degrees, resolution); //drawing cylider for Teflon tape roll
    drawCylinder2(4, -4, radius / 2, height - height, 0, 0, 0, degrees, resolution); // drawing the black cyinder in the center of the yellow teflon tape


    drawCylinder3(4, -4, radius, height, 84, 255, 0, degrees, resolution); //drawing green cylider for massage ball
    drawCylinder4(4, -4, radius / 2, height, 255, 255, 255, degrees, resolution); //drawing white cylinder for massage ball
    drawCylinder5(4, -4, (radius / 2) / 2, height + 1.0, 0, 0, 0, degrees, resolution); //drawing black ball cylider for Teflon tape roll


}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, &mesh.vbo); //deletes the buffers
}

bool UCreateTexture(const char* filename, GLuint& myTexture)
{
    int width, height, channels; //declaring variables
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels); //will flip the image since it is imported flipped

        glGenTextures(1, &myTexture);
        glBindTexture(GL_TEXTURE_2D, myTexture); // binding the texture

        //setting the wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); //wrap around the S(x) axis
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); //wrap around the T(y) axis 

        //setting the filterint parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // this will be the minifying
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); //this is the magnifying 

        if (channels == 3) //acounts for channels with RGB
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)//accounts for channels with RGBA 
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "there is no image/picture with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D); //genertating mipmap

        stbi_image_free(image); //releasing the image data
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the current texture

        return true;
    }

    // if there is an error loading the image then return false
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& myShader)
{
    // Compilation and  error reporting
    int success = 0;
    char infoLog[512];

    // Creates an object of the Shader program .
    myShader = glCreateProgram();


    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER); //Creates vertex shader objects
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);//creates fragment shader objects


    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);//retrieves the vertex shader source
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);//retriieves the fragment shader source


    glCompileShader(vertexShaderId); //compile the vertex shader

    // checking for compile failures
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);// gets the vertex shader info log
        cout << "SHADER VERTEX CREATION FAILED!" << infoLog << endl; //error message will print if it did not compile correctly

        return false; //if it was not compiled corectly the boolean will return false
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
   // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        cout << "Shader Fragment/Vector failed!" << infoLog << endl;

        return false;
    }


    glAttachShader(myShader, vertexShaderId);//attach shaders to the vertex shader program 
    glAttachShader(myShader, fragmentShaderId);//attach shaders to the fragment shader program

    glLinkProgram(myShader); //links the shader program

    // checking for linking errors
    glGetProgramiv(myShader, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(myShader, sizeof(infoLog), NULL, infoLog);
        cout << "SHADER PROGRAM LINK FAILED!" << infoLog << endl;

        return false; //will return false if was not correctly linked
    }

    glUseProgram(myShader);    // Uses the myShader program

    return true; //returns true if executed correctly
}

void UDestroyShaderProgram(GLuint myShader) { //destroy shader method

    glDeleteProgram(myShader); //deletes the shader since we no longer need them
}
